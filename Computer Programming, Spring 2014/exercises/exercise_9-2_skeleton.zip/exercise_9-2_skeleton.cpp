#include <iostream>
#include <string>
#include <vector>

using namespace std;

template<typename T>
class Database {
private:
	vector<T> data;
public :
	// TODO
	Database();
	
	// TODO
	void insert_data(T input);
	
	// TODO
	void select_data(bool (*checker)(const T));
	
	// TODO
	void delete_data(bool (*checker)(const T));
};


bool checker_function_1(const int x) {
	return x > 10;
}

bool checker_function_2(const int x) {
	return x < 5;
}

int main() {
	const string menu = "1. insert\n2. select\n3. delete\n4. Quit\nChoose action : ";
	const string checker_menu = "1. All\n2. function1(select/delete bigger than 10)\n"
			"3. function2(select/delete smaller than 5)\nChoose checker function : ";
	
	Database<int> data_int;
	int input_int;
	int argument_int;
	
	while (true) {
		cout << menu;
		cin >> input_int;
		
		switch (input_int) {
			case 1:
				cout << "Enter the value : ";
				cin >> argument_int;
				
				data_int.insert_data(argument_int);
				break;
				
			case 2:
				cout << checker_menu;
				cin >> input_int;
				
				if (input_int == 1) {
					data_int.select_data(nullptr);
				}
				else if (input_int == 2) {
					data_int.select_data(checker_function_1);
				}
				else if (input_int == 3) {
					data_int.select_data(checker_function_2);
				}
				break;
				
			case 3:
				cout << checker_menu;
				cin >> input_int;
				
				if (input_int == 1) {
					data_int.delete_data(nullptr);
				}
				else if (input_int == 2) {
					data_int.delete_data(checker_function_1);
				}
				else if (input_int == 3) {
					data_int.delete_data(checker_function_2);
				}
				break;
				
			case 4:
				return 0;
		}
	}
}

