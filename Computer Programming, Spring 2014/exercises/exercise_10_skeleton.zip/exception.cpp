#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;

int main() {
	string s;
	string arg1, arg2;
	
	// TODO : check each argument(arg1,arg2) is "int type", which means there is no any other letters than 0-9.
	//        Catch the exception with exception handler
	//       There is no empty space in equation
	// TODO : Check for 'division by zero' with exception handler
	while (true) {
		cout << "Enter the equation(+,-,*,/,%) : ";
		getline(cin, s);
		
		if (s.find("+") != string::npos) {
			arg1 = s.substr(0, s.find("+"));
			arg2 = s.substr(s.find("+") + 1, s.length());
			int farg = atoi(arg1.c_str());
			int sarg = atoi(arg2.c_str());
			cout << farg + sarg << endl;
		}
		else if (s.find("-") != string::npos) {
			arg1 = s.substr(0, s.find("-"));
			arg2 = s.substr(s.find("-") + 1, s.length());
			int farg = atoi(arg1.c_str());
			int sarg = atoi(arg2.c_str());
			cout << farg - sarg << endl;
		}
		else if (s.find("*") != string::npos) {
			arg1 = s.substr(0, s.find("*"));
			arg2 = s.substr(s.find("*") + 1, s.length());
			int farg = atoi(arg1.c_str());
			int sarg = atoi(arg2.c_str());
			cout << farg * sarg << endl;
		}
		else if (s.find("/") != string::npos) {
			arg1 = s.substr(0, s.find("/"));
			arg2 = s.substr(s.find("/") + 1, s.length());
			int farg = atoi(arg1.c_str());
			int sarg = atoi(arg2.c_str());
			cout << farg / sarg << endl;
		}
		else if (s.find("%") != string::npos) {
			arg1 = s.substr(0, s.find("%"));
			arg2 = s.substr(s.find("%") + 1, s.length());
			int farg = atoi(arg1.c_str());
			int sarg = atoi(arg2.c_str());
			cout << farg % sarg << endl;
		}
		else if (s == "quit") {
			break;
		}
		else {
			// TODO : Use appropriate exception that you've defined.
		}
	}
	return 0;
}