import java.awt.Choice;
import java.awt.Color;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class ChoiceController {
	private DrawingFrame bT;
	
	public ChoiceController(DrawingFrame jF)
	{
				
		bT = jF;
	}
	
	private class LocalColorChoiceHandler implements ItemListener{
		public void itemStateChanged(ItemEvent arg0) {
	

		}
	}
		
	private class LocalFillChoiceHandler implements ItemListener{
		public void itemStateChanged(ItemEvent arg0) {
			

		}
	}
}