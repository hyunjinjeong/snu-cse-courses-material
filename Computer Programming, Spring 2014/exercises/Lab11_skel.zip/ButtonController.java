import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonController {
	private DrawingFrame bT;
	
	public ButtonController(DrawingFrame jF)
	{
		
		bT = jF;
	}
	
	private class LocalButtonHandler implements ActionListener {
		public void actionPerformed(ActionEvent ae) {
		
		}
	}
}