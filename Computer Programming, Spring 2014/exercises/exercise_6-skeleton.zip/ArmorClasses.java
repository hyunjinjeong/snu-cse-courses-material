// TODO
class IronmanRepulsor {
}


// TODO
class IronmanFireBlaster {
}


// TODO
class IronmanWhipFlash {
}


// TODO
class IronmanRepulsorFireBlaster {
}


// TODO
class IronmanRepulsorWhipFlash {
}


// TODO
class IronmanHulkBuster {
}




