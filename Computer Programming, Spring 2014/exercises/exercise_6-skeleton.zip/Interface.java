interface Repulsor {
	int repulsorDamage();	//have initial health +0 | deals additional 5 damage
}

interface FireBlaster {
	int fireBlasterDamage();//have initial health +0 | deals additional 15 damage, but damaged 5 health
}

interface WhipFlash {
	int whipFlashDamage();	//have initial health -30 | deals additional 3 damage, and heals 3 health
}

interface HulkBuster {
	int hulkBusterDamage();	//have initial health +50 | deals additional -2 damage
}


class Ironman {
	protected String name;
	protected int health;

	public Ironman(String name) {
		this.name = name;
		setHealth();
	}

	public String getName() {
		return name;
	}

	public int deal() {
		return 5;
	}

	protected void setHealth() {
		this.health = 50;
	}

	public void damaged(int damage) {
		this.health -= damage;
	}

	public boolean isDead() {
		return health <= 0;
	}

	@Override
	public String toString() {
		return name + "[" + health + "]";
	}
}
